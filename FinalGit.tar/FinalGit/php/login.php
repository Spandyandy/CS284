<?php 

  $host = "crisler.sewanee.edu";
  $user = "webuser";
  $pass = "9083ughf4";
  $db   = "professorArchives";

?>
