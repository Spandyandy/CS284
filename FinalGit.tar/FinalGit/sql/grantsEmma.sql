GRANT SELECT,DELETE,UPDATE,INSERT ON professorArchives.*  TO webuser@localhost             IDENTIFIED BY '9083ughf4';
GRANT SELECT,DELETE,UPDATE,INSERT ON professorArchives.*  TO webuser@'%.sewanee.edu'       IDENTIFIED BY '9083ughf4';
GRANT SELECT,DELETE,UPDATE,INSERT ON professorArchives.*  TO webuser@'%'                   IDENTIFIED BY '9083ughf4';
