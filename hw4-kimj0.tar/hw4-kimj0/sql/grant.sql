GRANT SELECT, INSERT ON supercars.* TO guest@Crisler.sewanee.edu IDENTIFIED BY 'minimin';
