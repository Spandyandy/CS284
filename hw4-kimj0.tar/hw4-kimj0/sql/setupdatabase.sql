create database supercars;
use supercars;

