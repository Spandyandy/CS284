<?php // login.php

  $hn = "Crisler.sewanee.edu";
  $un = "guest";
  $pw = "minimin";
  $db = "supercars";

?>
